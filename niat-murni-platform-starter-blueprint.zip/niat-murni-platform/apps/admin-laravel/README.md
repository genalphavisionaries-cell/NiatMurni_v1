# admin-laravel (Laravel + Filament)

Ops Admin + Finance/Compliance Admin UI. Thin client to Go Core.

## Run (local)
```bash
cp .env.example .env
composer install
php artisan serve
```

## Rules
- Do NOT store business truth in Laravel DB.
- All reads/writes go through Go API.
